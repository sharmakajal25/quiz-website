const mongoose=require("mongoose");
const express=require("express");
const dotenv=require('dotenv').config();
const app=express();
const cors=require('cors');
app.use(express.json())
app.use(express.urlencoded())
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));
const userSchema=new mongoose.Schema({
   name:"String",
   email:"String",
   password:"String",
   age:"String",
   collegeAddress:"String",
   branch:"String",
   courses:"String"
})
const User =new mongoose.model("User",userSchema)
mongoose.set('strictQuery',true);
mongoose.connect('mongodb+srv://sharmakajal3497:zUNEI7wSMA0CSnCq@cluster0.ivjdmkt.mongodb.net/?retryWrites=true&w=majority',{useNewUrlParser:true,useUnifiedTopology:true})
.then((result)=>console.log("Connected to Database"))
.catch((err)=>console.log(err));
app.post('/login', async (req, res) => {
    try {
      const { email, password } = req.body
      const user = await User.findOne({ email })
  
      if (!user) {
        return res.status(400).json({ message: 'Incorrect email or password.' })
      }
  
      if (password !== user.password) {
        return res.status(400).json({ message: 'Incorrect email or password.' })
      }
  
      res.json({ message: 'login success',user })
    } catch (err) {
      console.error(err)
      res.status(500).json({ message: 'Server error' })
    }
  })
app.post("/register",(req,res)=>{
    console.log(req.body) 
    const {name,email,password,age,branch,collegeAddress} =req.body;
    User.findOne({email:email })
        .then(user =>{
            if(user){
                res.send({ message: "user already exists" })
            }else{
                const user = new User({ name, email, password,age,branch,collegeAddress })
                user.save()
                    .then(()=> {
                        res.send({ message: "successfully registered!!!" })
                    })
                    .catch(err => {
                        console.log(err);
                        res.send("error occurred");
                    });
            }
        })
        .catch(err => {
            console.log(err);
            res.send("error occurred");
        });
});
app.get("/user", (req, res) => {
  const email = req.params.email;
  User.findOne(email)
    .then((user) => {
      if (!user) {
        res.status(404).json({ message: "User not found" });
      } else {
        res.json({ user });
      }
    })
    .catch((err) => {
      console.log(err);
      res.status(500).json({ message: "Server error" });
    });
});
app.listen(5000,()=>{
    console.log("Backend Started at port 5000")
})