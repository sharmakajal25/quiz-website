import React, { useState } from 'react';
import "../styles/signup.css"
import axios from 'axios';

function Signup() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [age, setAge] = useState('');
  const [collegeAddress, setCollegeAddress] = useState('');
  const [branch, setBranch] = useState('');
  const [courses, setCourses] = useState([]);
  const [file, setFile] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Form validation
    if (!name.trim() || !email.trim() || !password.trim() || !age.trim() || !collegeAddress.trim() || !branch || !courses.length) {
      alert("Please fill in all fields.");
      return;
    }

    if (age < 20 || age > 60) {
      alert("Age must be between 20 and 60.");
      return;
    }
    

    if (courses.length < 2) {
      alert("Please select at least 2 courses.");
      return;
    }

    // You can add your logic for form submission here
      if (name && email && password) {
        try {
          await axios.post("http://localhost:5000/register",{
            name:name,
            email:email,
            password:password,
            age:age,
            branch:branch,
            collegeAddress:collegeAddress
          });
          alert("Registration successful!");
        } catch (error) {
          alert("Registration failed. Please try again.");
        }
      } else {
        alert("Please fill in all the fields and make sure your passwords match.");
      }
    //console.log(`Name: ${name}, Email: ${email}, Password: ${password}, Age: ${age}, College Address: ${collegeAddress}, Branch: ${branch}, Courses: ${courses}, File: ${file.name}`);
  }

  function handleCoursesChange(event) {
    const selectedCourses = Array.from(event.target.selectedOptions, option => option.value);
    setCourses(selectedCourses);
  }
   

  function handleFileChange(event) {
    setFile(event.target.files[0]);
  }
  return (
    <div className='form-container'>
      <h1>Registration Form</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input type="text" value={name} onChange={event => setName(event.target.value)} required />
        </label>
        <label>
          Email:
          <input type="email" value={email} onChange={event => setEmail(event.target.value)} required />
        </label>
        <label>
          Password:
          <input type="password" value={password} onChange={event => setPassword(event.target.value)} required />
        </label>
        <label>
          Age:
          <input type="number" value={age} onChange={event => setAge(event.target.value)} onClick={event=> handleSubmit()} min="20" max="60" required />
        </label>
        <label>
          College Address:
          <textarea value={collegeAddress} onChange={event => setCollegeAddress(event.target.value)} required />
        </label>
        <label>
          Branch:
          <select value={branch} onChange={event => setBranch(event.target.value)} required>
            <option value="">Select branch</option>
            <option value="computer science">Computer Science</option>
            <option value="electrical engineering">Electrical Engineering</option>
            <option value="mechanical engineering">Mechanical Engineering</option>
            <option value="civil engineering">Civil Engineering</option>
          </select>
        </label>
        <label>
  Courses Available:
  <select multiple value={courses} onChange={handleCoursesChange} required>
    <option value="javascript">JavaScript</option>
    <option value="python">Python</option>
    <option value="java">Java</option>
    <option value="ruby">C++</option>
  </select>
  </label>

        <label>
          Upload Folder:
          <input type="file" onChange={handleFileChange} required />
        </label>
        <button type="submit">Submit</button>

          {/* <button type="reset" class="btn btn-danger">Reset</button> */}
          <button type="button" class="btn btn-danger" onClick={() => {
              setName('');
              setEmail('');
              setPassword('');
              setAge('');
              setCollegeAddress('');
              setBranch('');
              setCourses([]);
              setFile(null);
            }}>Reset</button>

    </form>
    </div>
  );
}
export default Signup;

