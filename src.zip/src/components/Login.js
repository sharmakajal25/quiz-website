import React, { useState } from 'react'
import '../styles/login.css'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { useNavigate } from 'react-router-dom';


export default function Login() {
  
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [message, setMessage] = useState('')
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault()
    axios.post('http://localhost:5000/login', { email, password })
      .then(response => {
        if (response.data.message === 'login success') {
          setMessage('Login successful!')
          navigate('/main');
        } else {
          setMessage('Incorrect email or password.')
        }
      })
      .catch(error => {
        setMessage(error.response.data.message)
      })
  }
  
  

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="email">Email:</label>
        <input type="email" id="email" name="email" value={email} onChange={(event) => setEmail(event.target.value)} />
        <br />
        <label htmlFor="password">Password:</label>
        <input type="password" id="password" name="password" value={password} onChange={(event) => setPassword(event.target.value)} />
        <br />
        <div id="message">{message}</div>
        <button type="submit">Login</button>
      </form>
      <Link className='btn' to={'../signup'}>Register</Link>
    </div>
  )
}
