import React from 'react'
import { Link } from 'react-router-dom'
const Ask = () => {
    return (
     
        <div className="login-container">
        <h2>Please Login First!!</h2>
        <Link className='btn' to={'../login'}>Login</Link>
        </div>
       
    );
   
  };
  
  export default Ask;
  