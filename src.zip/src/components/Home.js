// import React from 'react';
import '../styles/home.css';

// function Home() {
//   return (
//     <div className="home-container">
//       <img src="https://www.zehntech.com/wp-content/uploads/2020/08/E-learning.jpg" width="100%" alt="Home Image" />
//       <div className="description">
//         <h1>E-Graduation Website!</h1>
//         <p>This page contains resources for graduating students, including information about diplomas and electronic diplomas, commencement, completion of degree requirements, and more. 
// This page contains graduation information for students. Faculty and staff seeking graduation management resources may view the Graduation Management for Departments webpage. 

// Graduation Steps
// Students expected to graduate can find important actions they should take prior to graduation, such as reviewing degree info & status, checking account balance, updating contact info, and more.
// About Commencement
// Degrees are conferred by academic departments in August, December and May of each calendar year. The campus-wide Commencement Ceremony is held in May on the Pittsburgh campus.

// About Diplomas
// Learn more about diplomas at CMU, steps students expected to graduate need to take, deadlines for updating info, distribution timelines, how to order an electronic diploma, & more. 
// About CeDiplomas
// Certified Electronic Diplomas (CeDiplomas) are the secure, electronic counterpart to a student's paper diploma. Easy to share with family, friends and future employers, CeDiplomas are provided to Carnegie Mellon graduates free of charge. </p>
//       </div>
//       <div className="footer">
//         <p>Contact me at:</p>
//         <input type="email" placeholder="Enter your email address" />
//        <button alt="www.gmail.com">Submit</button>
//       </div>
//     </div>

    


   
//   );
// }

// export default Home;
import React from 'react';
//import './Home.css'; // Create a corresponding Home.css file and include the provided CSS styles.
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAtom, faSkiing, faEthernet } from '@fortawesome/free-solid-svg-icons';

const Home = () => {
  return (
    <div>
      <header className="header">
        <a href="#" className="logo">Quiz-Platform</a>
      </header>
      <main>
        <div className="intro">
          <h1>Quiz-Website</h1>
          <p>Quizzes are like treasure hunts for knowledge.</p>
          <button> <a href=" https://quizizz.com/" target="_blank">Learn More</a></button>
        </div>
        <div className="achievements">
          <div className="work">
            <FontAwesomeIcon icon={faAtom} />
            <p className="work-heading"> Benefits of Quizzes</p>
            <p className="work-text">Quizzes encourage active learning and engagement with the content.
Regular quizzing helps reinforce knowledge and improve retention.
Quizzes provide instant feedback, allowing learners to identify areas of improvement.</p>
          </div>
          <div className="work">
            <FontAwesomeIcon icon={faSkiing} />
            <p className="work-heading">Skills</p>
            <p className="work-text">Content Knowledge: Understanding the subject matter and having expertise in the topics you are creating quizzes for.

Question Design: Ability to craft well-formulated and clear questions that assess the learners' understanding effectively.</p>
          </div>
          <div className="work">
            <FontAwesomeIcon icon={faEthernet} />
            <p className="work-heading">Training and Education</p>
            <p className="work-text">Quizzes are valuable tools for formative assessments during classroom learning.
They are widely used in e-learning platforms to track learner progress.
Quizzes can be used for pre-assessment to gauge learners' prior knowledge.</p>
          </div>
        </div>
        <div className="about-me">
          <div className="about-me-text">
            <h2>About Me</h2>
            <p>I am a web developer and I love to create websites. I am a very good developer and I am always looking for new projects. I am a very good developer and I am always looking for new projects.</p>
          </div>
          <img src="https://images.unsplash.com/photo-1596495578065-6e0763fa1178?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=871&q=80" alt="me" />
        </div>
      </main>
      <footer className="footer">
        <div className="copy">© 2022 Developer</div>
        <div className="bottom-links">
          <div className="links">
            <span>More Info</span>
            <a href="#">Home</a>
            <a href="#">Email - sharmakajal3497@gmail.com</a>
            <a href="#">Contact - 9510868637</a>
          </div>
          <div className="links">
            <span>Social Links</span>
            <a href="#"><FontAwesomeIcon icon={['fab', 'facebook']} /></a>
            <a href="#"><FontAwesomeIcon icon={['fab', 'twitter']} /></a>
            <a href="#"><FontAwesomeIcon icon={['fab', 'instagram']} /></a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;






