import React, { useState, useEffect } from 'react'
import axios from 'axios'

export default function MyWall() {

  const [userData, setUserData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    axios.get('http://localhost:5000/user')
      .then(response => {
        setUserData(response.data)
        setIsLoading(false)
      })
      .catch(error => {
        console.log(error)
      })
  }, [])

  return (
    <div className="main-container">
      <h2>Welcome to your main page</h2>
      
        <div>
          <p>Name: Kajal Sharma</p>
          <p>Email: sharmakajal3497@gmail.com</p>
          <p>Age: 24</p>
          <p>College Address: Patia,Bbsr</p>
          {/* Add additional user data fields here */}
        </div>
      
    </div>
  )
}



