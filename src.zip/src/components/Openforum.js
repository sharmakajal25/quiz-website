// import React, { useState, useEffect } from 'react';

// function OpenForum() {
//   const [queries, setQueries] = useState([]);

//   useEffect(() => {
//     // Load queries from localStorage on component mount
//     const localStorageQueries = [];
//     for (let i = 0; i < localStorage.length; i++) {
//       const key = localStorage.key(i);
//       const queryData = JSON.parse(localStorage.getItem(key));
//       localStorageQueries.push({ key, ...queryData });
//     }
//     setQueries(localStorageQueries);
//   }, []);

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     const queryInput = event.target.elements.query;
//     const query = queryInput.value;
//     if (query !== '') {
//       const timestamp = new Date().toLocaleString();
//       const key = Date.now().toString();
//       const newQuery = { key, query, timestamp, resolved: false };
//       setQueries((prevQueries) => [...prevQueries, newQuery]);
//       localStorage.setItem(key, JSON.stringify(newQuery));
//       queryInput.value = '';
//     }
//   };

//   const handleResolve = (key) => {
//     setQueries((prevQueries) =>
//       prevQueries.map((query) => {
//         if (query.key === key) {
//           const resolvedQuery = { ...query, resolved: true };
//           localStorage.setItem(key, JSON.stringify(resolvedQuery));
//           return resolvedQuery;
//         }
//         return query;
//       })
//     );
//   };

//   const handleDelete = (key) => {
//     setQueries((prevQueries) =>
//       prevQueries.filter((query) => {
//         if (query.key === key) {
//           localStorage.removeItem(key);
//           return false;
//         }
//         return true;
//       })
//     );
//   };

//   return (
//     <div>
//       <h1>Student Forum</h1>
//       <form onSubmit={handleSubmit}>
//         <textarea name="query" placeholder="Enter your query"></textarea>
//         <button type="submit">Post Query</button>
//       </form>
//       <div>
//         {queries.map((query) => (
//           <div key={query.key} className={`post${query.resolved ? ' resolved' : ''}`}>
//             <p>{query.query}</p>
//             <span className="timestamp">{query.timestamp}</span>
//             <button onClick={() => handleResolve(query.key)} disabled={query.resolved}>
//               Resolve
//             </button>
//             <button onClick={() => handleDelete(query.key)}>Delete</button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default OpenForum;

import React, { useState, useEffect } from 'react';

function OpenForum() {
  const [queries, setQueries] = useState([]);

  useEffect(() => {
    // Load queries from localStorage on component mount
    const localStorageQueries = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      const queryData = JSON.parse(localStorage.getItem(key));
      localStorageQueries.push({ key, ...queryData });
    }
    setQueries(localStorageQueries);
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    const queryInput = event.target.elements.query;
    const query = queryInput.value;
    if (query !== '') {
      const timestamp = new Date().toLocaleString();
      const key = Date.now().toString();
      const newQuery = { key, query, timestamp, resolved: false, reply: '' };
      setQueries((prevQueries) => [...prevQueries, newQuery]);
      localStorage.setItem(key, JSON.stringify(newQuery));
      queryInput.value = '';
    }
  };

  const handleResolve = (key, reply) => {
    setQueries((prevQueries) =>
      prevQueries.map((query) => {
        if (query.key === key) {
          const resolvedQuery = { ...query, resolved: true, reply };
          localStorage.setItem(key, JSON.stringify(resolvedQuery));
          return resolvedQuery;
        }
        return query;
      })
    );
  };

  const handleDelete = (key) => {
    setQueries((prevQueries) =>
      prevQueries.filter((query) => {
        if (query.key === key) {
          localStorage.removeItem(key);
          return false;
        }
        return true;
      })
    );
  };

  return (
    <div>
      <h1>Student Forum</h1>
      <form onSubmit={handleSubmit}>
        <textarea name="query" placeholder="Enter your query"></textarea>
        <button type="submit">Post Query</button>
      </form>
      <div>
        {queries.map((query) => (
          <div key={query.key} className={`post${query.resolved ? ' resolved' : ''}`}>
            <p>{query.query}</p>
            <span className="timestamp">{query.timestamp}</span>
            {!query.resolved && (
              <div>
                <textarea
                  value={query.reply}
                  onChange={(e) =>
                    setQueries((prevQueries) =>
                      prevQueries.map((q) => {
                        if (q.key === query.key) {
                          return { ...q, reply: e.target.value };
                        }
                        return q;
                      })
                    )
                  }
                  placeholder="Enter your reply"
                ></textarea>
                <button onClick={() => handleResolve(query.key, query.reply)}>Resolve</button>
              </div>
            )}
            {query.resolved && (
              <div>
                <p className="resolved-message">This query has been resolved.</p>
                <p className="reply-message">Reply: {query.reply}</p>
              </div>
            )}
            <button onClick={() => handleDelete(query.key)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default OpenForum;
