import React, {useRef} from 'react'
import {Link } from 'react-router-dom'
import '../styles/Main.css'

export default function Main() {

    const inputRef = useRef(null)

  return (
    <div className='container'>
    <h1 className='title text-light'>
        Quiz Application
    </h1>
    <ol>
        <li>You will be asked 10 questions one after another.</li>
        <li>10 points will be awarded for the correct answers.</li>
        <li>Eacg question will have 3 options.</li>
        <li>You can review the answers before the quiz finish.</li>
        <li>Result will be declared at the end of the quiz.</li>
    </ol>

    <div className='start'>
        <Link className='btn' to={'quiz'}>Start Quiz</Link>
    </div>

    </div>
  )
}