import React, { useState, useEffect } from 'react';
import '../styles/repo.css';

const Repo = () => {
  const [repoData, setRepoData] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);

  const handleDownload = (url) => {
    // open the file in a new tab
    const newTab = window.open();
    newTab.document.body.innerHTML = `<iframe src="${url}" width="100%" height="100%"></iframe>`;

    // create a download link and append it to the body
    const link = document.createElement('a');
    link.href = url;
    link.download = url.split('/').pop();
    newTab.document.body.appendChild(link);
    link.click();
  };

  const handleFileSelect = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleUpload = () => {
    if (selectedFile) {
      const reader = new FileReader();
      reader.onload = () => {
        const newFile = {
          name: selectedFile.name,
          url: reader.result,
        };
        const updatedRepoData = [...repoData, newFile];
        localStorage.setItem('repoData', JSON.stringify(updatedRepoData));
        setRepoData(updatedRepoData);
      };
      reader.readAsDataURL(selectedFile);
      setSelectedFile(null);
    }
  };

  const handleDelete = (index) => {
    const updatedRepoData = repoData.filter((file, i) => i !== index);
    localStorage.setItem('repoData', JSON.stringify(updatedRepoData));
    setRepoData(updatedRepoData);
  };

  useEffect(() => {
    const storedRepoData = JSON.parse(localStorage.getItem('repoData')) || [];
    setRepoData(storedRepoData);
  }, []);

  return (
    <div className="repo-container">
      <h1>e-Repository</h1>
      {repoData.length > 0 ? (
        <ul>
          {repoData.map((data, index) => (
            <li key={index}>
              <span>{data.name}</span>
              <button onClick={() => handleDownload(data.url)}>Download</button>
              <button onClick={() => handleDelete(index)}>Delete</button>
            </li>
          ))}
        </ul>
      ) : (
        <p>No files uploaded yet.</p>
      )}
      <div>
        <h2>Add a file to the repository:</h2>
        <input type="file" onChange={handleFileSelect} />
        <button onClick={handleUpload}>Upload</button>
      </div>
    </div>
  );
};

export default Repo;
