import React from 'react'
import {Routes,Route,Navigate} from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from './components/Home'
import Signup from './components/Signup'
import Login from "./components/Login"
import Main from './components/Main'
import QuizComp from './components/QuizComp'
import MyWall  from './components/MyWall'
import Ask from './components/Ask'
import "./App.css";
import OpenForum from './components/Openforum'
import Repo from './components/Repo'

const App = () => {
  return (
    <>
    <Navbar />
     <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/main" element={<Main />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="main/quiz" element={<QuizComp />} />
        <Route path="/mywall" element={<MyWall />} />
        <Route path="/ask" element={<Ask />} />
        <Route path="/open" element={<OpenForum />} />
        <Route path="/repo" element={<Repo />} />
        
      </Routes>
   
    </>
    

    
  );
 
};

export default App;
